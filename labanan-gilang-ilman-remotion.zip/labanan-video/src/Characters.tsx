import React from "react";

// ---------- util warna ----------
const hex = (c: string) => [1, 3, 5].map((i) => parseInt(c.slice(i, i + 2), 16));
const mix = (c: string, to: number, a: number) =>
  "#" + hex(c).map((v) => Math.round(v + (to - v) * a).toString(16).padStart(2, "0")).join("");

// Gradasi clay: terang kiri atas, gelap kanan bawah (userSpaceOnUse supaya garis lurus juga ikut)
const Grad: React.FC<{id: string; color: string}> = ({id, color}) => (
  <linearGradient id={id} gradientUnits="userSpaceOnUse" x1={-150} y1={-720} x2={170} y2={-60}>
    <stop offset="0" stopColor={mix(color, 255, 0.28)} />
    <stop offset="1" stopColor={mix(color, 0, 0.22)} />
  </linearGradient>
);

// ---------- ekspresi (parameter dari DOC-ekspresi_wajah.txt) ----------
export type Expr = {open: number; curve: number; mo: number; mw: number; brow: number; ang: number; pup: number; bl: number};
const base: Expr = {open: 0.95, curve: 0.25, mo: 0, mw: 40, brow: 0.1, ang: 0, pup: 1, bl: 0};
export const EXPR: Record<string, Expr> = {
  neutral: base,
  smile: {...base, open: 0.85, curve: 0.95, mo: 0.35, mw: 56, brow: 0.2, bl: 0.9},
  laugh: {...base, open: 0.05, curve: 1, mo: 1, mw: 60, brow: 0.3, bl: 0.9},
  hype: {...base, open: 1.1, curve: 0.9, mo: 0.7, mw: 54, brow: 0.7, pup: 1.2, bl: 0.9},
  smug: {...base, open: 0.6, curve: 0.7, mw: 50, brow: 0.1, ang: -0.4, bl: 0.5},
};

// ---------- pose lengan (koordinat lokal karakter, kaki di y=0) ----------
export type Pt = [number, number];
export type Arm = {e: Pt; h: Pt};
const SL: Pt = [-92, -535];
const SR: Pt = [92, -535];
export const REST_L: Arm = {e: [-122, -440], h: [-128, -350]};
export const REST_R: Arm = {e: [122, -440], h: [128, -350]};
export const waveR = (f: number): Arm => ({e: [160, -570], h: [175 + Math.sin(f * 0.35) * 28, -690]});
export const hugOver = (): Arm => ({e: [200, -520], h: [262, -548]});
export const sipR = (): Arm => ({e: [125, -470], h: [48, -612]});
export const holdR = (): Arm => ({e: [118, -445], h: [105, -420]});

type Props = {
  kind: "gilang" | "ilman";
  x: number; y: number; scale?: number; frame: number;
  expr?: Expr; talking?: boolean; armL?: Arm; armR?: Arm; cup?: "R" | null; flip?: boolean;
};

export const Character: React.FC<Props> = ({kind, x, y, scale = 1, frame, expr = EXPR.smile, talking, armL = REST_L, armR = REST_R, cup, flip}) => {
  const g = kind === "gilang";
  const id = kind;
  const skin = "#d9a074";
  const hair = "#1f1b22";
  const top = g ? "#4f7fd6" : "#2e2c35";
  const pants = g ? "#252a44" : "#1d1d22";
  const shoes = g ? "#c9a06a" : "#222226";
  const h = (g ? 1 : 160 / 165) * scale;
  const bob = Math.sin(frame * 0.09 + (g ? 0 : 1.7)) * 4;
  const blink = frame % 96 < 4 ? 0.05 : 1;
  const ex = {...expr, open: expr.open * (expr.open > 0.2 ? blink : 1)};
  const mo = talking ? 0.2 + 0.55 * Math.abs(Math.sin(frame * 0.55)) : ex.mo;
  const mw = ex.mw;

  const Eye = (cx: number) => (
    <g transform={`translate(${cx},-672)`}>
      <ellipse rx={20} ry={Math.max(2, 25 * ex.open)} fill="#2a1d1a" />
      {ex.open > 0.3 && <circle cx={-6} cy={-7 * ex.open} r={7 * ex.pup * 0.9} fill="#fff" />}
    </g>
  );
  const Brow = (cx: number, s: number) => (
    <line x1={cx - 20} y1={0} x2={cx + 20} y2={0} stroke={hair} strokeWidth={9} strokeLinecap="round"
      transform={`translate(0,${-722 - ex.brow * 14}) rotate(${s * ex.ang * -18},${cx},0)`} />
  );
  const c = ex.curve * 22;
  const mouth = mo > 0.12
    ? `M ${-mw / 2} 0 Q 0 ${c} ${mw / 2} 0 Q 0 ${c + mo * 42} ${-mw / 2} 0 Z`
    : `M ${-mw / 2} 0 Q 0 ${c * 1.4} ${mw / 2} 0`;

  const arm = (s: Pt, a: Arm, sleeveFull: boolean) => (
    <g>
      <line x1={s[0]} y1={s[1]} x2={a.e[0]} y2={a.e[1]} stroke={`url(#${id}-top)`} strokeWidth={48} strokeLinecap="round" />
      <line x1={a.e[0]} y1={a.e[1]} x2={a.h[0]} y2={a.h[1]} stroke={sleeveFull ? `url(#${id}-top)` : `url(#${id}-skin)`} strokeWidth={sleeveFull ? 42 : 36} strokeLinecap="round" />
      {sleeveFull && <circle cx={a.h[0]} cy={a.h[1]} r={23} fill="#16151a" />}
      <circle cx={a.h[0]} cy={a.h[1]} r={sleeveFull ? 17 : 22} fill={`url(#${id}-skin)`} />
    </g>
  );

  const Cup = () => (
    <g transform={`translate(${armR.h[0]},${armR.h[1] - 8})`}>
      <rect x={-20} y={-26} width={40} height={42} rx={9} fill="#f4ece2" stroke="#d8c8b4" strokeWidth={3} />
      <path d={`M 20 -14 q 20 4 0 22`} fill="none" stroke="#d8c8b4" strokeWidth={5} />
      {[ -8, 6 ].map((o, i) => (
        <path key={i} d={`M ${o} -34 q -8 -${14 + Math.sin(frame * 0.2 + i) * 4} 4 -${28}`} fill="none" stroke="#ffffff" strokeOpacity={0.7} strokeWidth={4} strokeLinecap="round" />
      ))}
    </g>
  );

  return (
    <g transform={`translate(${x},${y + bob}) scale(${flip ? -h : h},${h})`}>
      <defs>
        <Grad id={`${id}-skin`} color={skin} />
        <Grad id={`${id}-top`} color={top} />
        <Grad id={`${id}-pants`} color={pants} />
        <Grad id={`${id}-shoes`} color={shoes} />
        <Grad id={`${id}-hair`} color={hair} />
      </defs>
      <ellipse cx={0} cy={4 - bob} rx={150} ry={22} fill="#5a3a55" opacity={0.22} />
      {/* kaki */}
      {g ? (
        <>
          <rect x={-95} y={-345} width={90} height={250} rx={30} fill={`url(#${id}-pants)`} />
          <rect x={5} y={-345} width={90} height={250} rx={30} fill={`url(#${id}-pants)`} />
          <rect x={-97} y={-125} width={94} height={30} rx={14} fill="#c8c8cc" />
          <rect x={3} y={-125} width={94} height={30} rx={14} fill="#c8c8cc" />
          <rect x={-100} y={-98} width={92} height={98} rx={30} fill={`url(#${id}-shoes)`} />
          <rect x={8} y={-98} width={92} height={98} rx={30} fill={`url(#${id}-shoes)`} />
          <rect x={-100} y={-16} width={92} height={16} rx={8} fill="#efe0c0" />
          <rect x={8} y={-16} width={92} height={16} rx={8} fill="#efe0c0" />
        </>
      ) : (
        <>
          <rect x={-72} y={-190} width={46} height={165} rx={20} fill={`url(#${id}-skin)`} />
          <rect x={26} y={-190} width={46} height={165} rx={20} fill={`url(#${id}-skin)`} />
          <rect x={-100} y={-345} width={98} height={185} rx={28} fill={`url(#${id}-pants)`} />
          <rect x={2} y={-345} width={98} height={185} rx={28} fill={`url(#${id}-pants)`} />
          <rect x={-86} y={-32} width={72} height={32} rx={16} fill="#18181c" />
          <rect x={14} y={-32} width={72} height={32} rx={16} fill="#18181c" />
        </>
      )}
      {/* lengan belakang (kiri penonton) */}
      {arm(SL, armL, !g)}
      {/* badan */}
      <rect x={-100} y={-570} width={200} height={235} rx={42} fill={`url(#${id}-top)`} />
      {g ? (
        <>
          <path d="M -34 -570 L 0 -520 L 34 -570 Z" fill={mix(top, 255, 0.4)} />
          <circle cx={0} cy={-545} r={4} fill="#dfe8ff" />
          <circle cx={0} cy={-528} r={4} fill="#dfe8ff" />
          <rect x={-100} y={-372} width={200} height={22} rx={8} fill="#f7f4ef" />
          <rect x={-14} y={-374} width={28} height={26} rx={5} fill="#c9ccd2" />
        </>
      ) : (
        <>
          <line x1={-96} y1={-560} x2={-96} y2={-345} stroke="#e0505a" strokeWidth={5} />
          <line x1={96} y1={-560} x2={96} y2={-345} stroke="#e0505a" strokeWidth={5} />
          <text x={0} y={-480} textAnchor="middle" fontSize={34} fontWeight={900} fill="#fff" fontFamily="sans-serif">PSCLS</text>
          <path d="M -12 -520 h 24 v 14 q -12 10 -24 0 Z" fill="#fff" />
          <rect x={-8} y={-516} width={16} height={4} fill="#d33" /><rect x={-2} y={-522} width={4} height={14} fill="#d33" />
          <ellipse cx={0} cy={-440} rx={50} ry={14} fill="#fff" />
          <text x={0} y={-435} textAnchor="middle" fontSize={14} fontWeight={800} fill="#222" fontFamily="sans-serif">CULTURE</text>
        </>
      )}
      <rect x={-22} y={-590} width={44} height={36} rx={14} fill={`url(#${id}-skin)`} />
      {/* kepala */}
      <circle cx={-98} cy={-655} r={20} fill={`url(#${id}-skin)`} />
      <circle cx={98} cy={-655} r={20} fill={`url(#${id}-skin)`} />
      <circle cx={0} cy={-660} r={100} fill={`url(#${id}-skin)`} />
      {g ? (
        <path d="M -98 -672 Q -100 -770 0 -768 Q 100 -770 98 -672 Q 80 -722 0 -726 Q -80 -722 -98 -672 Z" fill={`url(#${id}-hair)`} />
      ) : (
        <>
          <path d="M -104 -660 Q -118 -780 0 -782 Q 118 -780 104 -660 Q 90 -730 0 -734 Q -90 -730 -104 -660 Z" fill={`url(#${id}-hair)`} />
          {[-60, -25, 15, 55].map((cx, i) => <circle key={i} cx={cx} cy={-762 + (i % 2) * 6} r={26} fill={`url(#${id}-hair)`} />)}
        </>
      )}
      {Eye(-36)}{Eye(36)}
      {Brow(-36, 1)}{Brow(36, -1)}
      <ellipse cx={-62} cy={-632} rx={20} ry={11} fill="#ff8f8f" opacity={ex.bl * 0.35} />
      <ellipse cx={62} cy={-632} rx={20} ry={11} fill="#ff8f8f" opacity={ex.bl * 0.35} />
      <g transform="translate(0,-612)">
        <path d={mouth} fill={mo > 0.12 ? "#7a2e3a" : "none"} stroke="#7a2e3a" strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" />
      </g>
      {/* lengan depan (kanan penonton) */}
      {arm(SR, armR, !g)}
      {cup === "R" && <Cup />}
    </g>
  );
};
