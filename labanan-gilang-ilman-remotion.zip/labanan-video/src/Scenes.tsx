import React from "react";
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from "remotion";
import {loadFont} from "@remotion/google-fonts/Poppins";
import {Character, EXPR, REST_L, REST_R, waveR, hugOver, sipR, holdR} from "./Characters";
import {FPS, tOf, SCENE_T} from "./timing";

const {fontFamily} = loadFont("normal", {weights: ["600", "800"], subsets: ["latin"]});
const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
const io = Easing.inOut(Easing.cubic);
const lerp = (f: number, a: number, b: number, x: number, y: number, e = io) =>
  interpolate(f, [a, b], [x, y], {...clamp, easing: e});

// ---------- latar langit senja pastel ----------
const Sky: React.FC<{h: number}> = ({h}) => (
  <>
    <defs>
      <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#a78bd0" /><stop offset="0.45" stopColor="#f0a8c0" />
        <stop offset="0.8" stopColor="#ffc89a" /><stop offset="1" stopColor="#ffdca8" />
      </linearGradient>
      <radialGradient id="sun"><stop offset="0" stopColor="#fff2c8" stopOpacity="0.95" /><stop offset="1" stopColor="#ffd9a0" stopOpacity="0" /></radialGradient>
    </defs>
    <rect width={1080} height={h} fill="url(#sky)" />
    <circle cx={760} cy={h - 330} r={260} fill="url(#sun)" />
    {[[140, 260, 1], [700, 180, 1.3], [880, 430, 0.8], [330, 520, 0.9]].map(([x, y, s], i) => (
      <g key={i} transform={`translate(${x},${y}) scale(${s})`} opacity={0.75}>
        <rect x={-120} y={-18} width={240} height={46} rx={23} fill="#fff1ea" />
        <circle cx={-30} cy={-24} r={34} fill="#fff1ea" /><circle cx={34} cy={-20} r={28} fill="#fff1ea" />
      </g>
    ))}
  </>
);

const House: React.FC<{x: number; y: number; s: number; c: string; r: string}> = ({x, y, s, c, r}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x={-70} y={-110} width={140} height={110} rx={16} fill={c} />
    <path d="M -90 -105 Q 0 -190 90 -105 Z" fill={r} />
    <rect x={-44} y={-78} width={34} height={40} rx={8} fill="#ffe08a" />
    <rect x={14} y={-78} width={34} height={40} rx={8} fill="#ffd36a" />
    <circle cx={0} cy={-118} r={0} />
  </g>
);

const Tree: React.FC<{x: number; y: number; s: number}> = ({x, y, s}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x={-18} y={-150} width={36} height={150} rx={16} fill="#a8795a" />
    <circle cx={0} cy={-210} r={110} fill="#7fbf8e" /><circle cx={-70} cy={-170} r={70} fill="#8ccb98" /><circle cx={72} cy={-176} r={72} fill="#76b585" />
    {[[-40, -230], [50, -200], [-80, -160], [10, -150]].map(([a, b], i) => <circle key={i} cx={a} cy={b} r={11} fill="#f08aa0" />)}
  </g>
);

const Village: React.FC<{shift: number}> = ({shift}) => (
  <>
    <Sky h={1920} />
    <path d="M0 1080 Q 260 1000 520 1070 T 1080 1040 V 1920 H0 Z" fill="#b8a0c8" opacity={0.6} />
    <g transform={`translate(${shift * 0.4},0)`}>
      {[60, 260, 470, 690, 900, 1110].map((x, i) => <House key={i} x={x} y={1130} s={0.8} c={["#f7d9c4", "#d9e4f5", "#f5e3b8"][i % 3]} r={["#d98c7a", "#9bb0d6", "#c79bb0"][i % 3]} />)}
    </g>
    <path d="M0 1160 H1080 V1920 H0 Z" fill="#a9d1a0" />
    <g transform={`translate(${-shift * 0.9},0)`}>
      {[-60, 230, 560, 880, 1180].map((x, i) => <House key={i} x={x} y={1400} s={1.4} c={["#f4cfc0", "#cfdcf2", "#f2dfae"][i % 3]} r={["#d4806e", "#8fa5cf", "#bf8fa8"][i % 3]} />)}
      {[110, 760, 1060].map((x, i) => <Tree key={i} x={x} y={1440} s={0.7} />)}
    </g>
    <path d="M 440 1160 L 640 1160 L 1000 1920 L 80 1920 Z" fill="#e8c9b0" />
    <path d="M 540 1180 V 1920" stroke="#fff4e2" strokeWidth={8} strokeDasharray="40 36" opacity={0.7} />
  </>
);

export const Fade: React.FC<{frames?: number; children: React.ReactNode}> = ({frames = 8, children}) => {
  const f = useCurrentFrame();
  return <AbsoluteFill style={{opacity: interpolate(f, [0, frames], [0, 1], clamp)}}>{children}</AbsoluteFill>;
};

// ---------- SCENE 1: drone orbit ----------
export const Scene1: React.FC = () => {
  const f = useCurrentFrame();
  const n = (SCENE_T[1] - SCENE_T[0]) * FPS;
  const p = f / n;
  return (
    <AbsoluteFill>
      <svg viewBox="0 0 1080 1920" width={1080} height={1920}>
        <g transform={`rotate(${Math.sin(p * Math.PI * 2) * 2.2},540,1100) translate(540,1100) scale(${1.08 + p * 0.08}) translate(-540,-1100)`}>
          <Village shift={Math.sin(p * Math.PI * 2) * 120} />
        </g>
      </svg>
      <div style={{position: "absolute", left: 70, top: 150, fontFamily, color: "#fff", opacity: lerp(f, 40, 70, 0, 1),
        transform: `translateY(${lerp(f, 40, 70, 20, 0)}px)`, textShadow: "0 4px 18px rgba(80,40,90,.45)"}}>
        <div style={{fontSize: 30, fontWeight: 600, letterSpacing: 6}}>📍 KALTIM</div>
        <div style={{fontSize: 64, fontWeight: 800}}>Labanan Makmur, Berau</div>
      </div>
    </AbsoluteFill>
  );
};

// ---------- SCENE 2: diving shot ----------
export const Scene2: React.FC = () => {
  const f = useCurrentFrame();
  const n = (SCENE_T[2] - SCENE_T[1]) * FPS;
  const z = lerp(f, 0, n, 1.15, 3.6, Easing.in(Easing.cubic));
  const lines = Array.from({length: 18}, (_, i) => i);
  return (
    <AbsoluteFill>
      <svg viewBox="0 0 1080 1920" width={1080} height={1920}>
        <g transform={`translate(540,1500) scale(${z}) translate(-540,-1500)`}><Village shift={0} /></g>
        <g opacity={lerp(f, n * 0.2, n * 0.7, 0, 0.65)} stroke="#fff" strokeLinecap="round">
          {lines.map((i) => {
            const a = (i / 18) * Math.PI * 2, r1 = 420 + ((f * 55 + i * 97) % 380), r2 = r1 + 220;
            return <line key={i} x1={540 + Math.cos(a) * r1} y1={960 + Math.sin(a) * r1 * 1.5} x2={540 + Math.cos(a) * r2} y2={960 + Math.sin(a) * r2 * 1.5} strokeWidth={6} />;
          })}
        </g>
      </svg>
      <AbsoluteFill style={{background: "#fff", opacity: lerp(f, n - 5, n, 0, 0.9)}} />
    </AbsoluteFill>
  );
};

// ---------- latar jalan kampung (scene 3-5) ----------
const Street: React.FC = () => (
  <svg viewBox="0 0 1080 1920" width={1080} height={1920} style={{position: "absolute"}}>
    <Sky h={1920} />
    <path d="M0 960 Q 300 900 560 950 T 1080 930 V 1920 H0 Z" fill="#b8a0c8" opacity={0.55} />
    {[80, 330, 600, 870].map((x, i) => <House key={i} x={x} y={1040} s={1} c={["#f7d9c4", "#d9e4f5", "#f5e3b8", "#f2d2d8"][i]} r={["#d98c7a", "#9bb0d6", "#c79bb0", "#a99bd0"][i]} />)}
    <rect x={0} y={1040} width={1080} height={880} fill="#a9d1a0" />
    <rect x={0} y={1560} width={1080} height={360} fill="#e8c9b0" />
    <rect x={0} y={1548} width={1080} height={20} fill="#d7b79e" />
    <Tree x={110} y={1500} s={1.5} />
    {[[200, 1050], [830, 1050]].map(([x, y], i) => <g key={i}><rect x={x - 5} y={y - 130} width={10} height={130} fill="#8a6c70" /><circle cx={x} cy={y - 140} r={16} fill="#ffe08a" /><circle cx={x} cy={y - 140} r={46} fill="#ffe9a8" opacity={0.35} /></g>)}
  </svg>
);

const Table: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x},${y})`}>
    <rect x={-8} y={-130} width={16} height={130} fill="#b58a62" />
    <rect x={-80} y={-150} width={160} height={26} rx={13} fill="#d7a678" />
    <ellipse cx={0} cy={4} rx={80} ry={12} fill="#5a3a55" opacity={0.2} />
  </g>
);

// ---------- SCENE 3: pengenalan lokasi ----------
export const Scene3: React.FC = () => {
  const f = useCurrentFrame();
  const n = (SCENE_T[3] - SCENE_T[2]) * FPS;
  const z = lerp(f, 0, n, 1.0, 1.1);
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{transform: `scale(${z})`, transformOrigin: "50% 60%"}}>
        <Street />
        <svg viewBox="0 0 1080 1920" width={1080} height={1920} style={{position: "absolute"}}>
          <Table x={560} y={1560} />
          <g transform={`translate(${lerp(f, 0, 25, 40, 0)},0)`} opacity={lerp(f, 0, 20, 0, 1)}>
            <Character kind="gilang" x={380} y={1620} scale={0.8} frame={f} expr={EXPR.smile} />
            <Character kind="ilman" x={760} y={1620} scale={0.8} frame={f} expr={EXPR.smile} armR={holdR()} cup="R" flip />
          </g>
        </svg>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

// ---------- SCENE 4: perkenalan ----------
export const Scene4: React.FC = () => {
  const f = useCurrentFrame();
  const t0 = SCENE_T[3];
  const tKalau = (tOf("kalau ini") || tOf("ini")) - t0;
  const tIlman = tOf("ilman.") - t0;
  const tHai = tOf("hai,") - t0;
  const pan = lerp(f, tKalau * FPS - 6, tKalau * FPS + 14, 0, -400);
  const iTalk = f / FPS > tIlman && f / FPS < tIlman + 1.1;
  const gTalk = !iTalk && f / FPS < tIlman - 0.2;
  const tag = (txt: string, color: string, at: number, y: number) => (
    <div style={{position: "absolute", left: 70, top: y, fontFamily, fontWeight: 800, fontSize: 54, color: "#fff", background: color,
      padding: "14px 40px", borderRadius: 60, boxShadow: "0 10px 24px rgba(60,30,70,.3)",
      opacity: lerp(f, at * FPS, at * FPS + 10, 0, 1) * (txt === "Gilang" ? lerp(f, tKalau * FPS + 10, tKalau * FPS + 22, 1, 0) : 1),
      transform: `translateX(${lerp(f, at * FPS, at * FPS + 12, -60, 0)}px)`}}>{txt}</div>
  );
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{filter: "blur(7px)", transform: "scale(1.15)"}}><Street /></AbsoluteFill>
      <svg viewBox="0 0 1080 1920" width={1080} height={1920} style={{position: "absolute"}}>
        <g transform={`translate(${pan},0)`}>
          <Character kind="gilang" x={540} y={1650} scale={1.1} frame={f} expr={EXPR.smile} talking={gTalk}
            armR={f / FPS > tHai - 0.2 && f / FPS < tKalau ? waveR(f) : REST_R} />
          <Character kind="ilman" x={960} y={1650} scale={1.1} frame={f} expr={iTalk ? EXPR.laugh : EXPR.smile} talking={iTalk} armR={holdR()} cup="R" flip />
        </g>
      </svg>
      {tag("Gilang", "#4f7fd6", Math.max(tHai, 0.2), 230)}
      <div style={{opacity: lerp(f, tIlman * FPS - 4, tIlman * FPS + 6, 0, 1)}}>{tag("Ilman", "#e0505a", 0, 230)}</div>
    </AbsoluteFill>
  );
};

// ---------- SCENE 5: closing ----------
export const Scene5: React.FC = () => {
  const f = useCurrentFrame();
  const n = (SCENE_T[5] - SCENE_T[4]) * FPS;
  const tSep = tOf("sepupuan") - SCENE_T[4];
  const hug = lerp(f, tSep * FPS, tSep * FPS + 14, 0, 1);
  const lerpPt = (a: [number, number], b: [number, number]): [number, number] => [a[0] + (b[0] - a[0]) * hug, a[1] + (b[1] - a[1]) * hug];
  const armR = {e: lerpPt(REST_R.e, hugOver().e), h: lerpPt(REST_R.h, hugOver().h)};
  const sip = Math.max(0, Math.sin(f * 0.08 - 1.2));
  const ilArm = {e: [holdR().e[0] + (sipR().e[0] - holdR().e[0]) * sip, holdR().e[1] + (sipR().e[1] - holdR().e[1]) * sip] as [number, number],
    h: [holdR().h[0] + (sipR().h[0] - holdR().h[0]) * sip, holdR().h[1] + (sipR().h[1] - holdR().h[1]) * sip] as [number, number]};
  const z = lerp(f, 0, n, 1.0, 1.08);
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{filter: "blur(5px)"}}><Street /></AbsoluteFill>
      <svg viewBox="0 0 1080 1920" width={1080} height={1920} style={{position: "absolute"}}>
        <g transform={`translate(540,1100) scale(${z}) translate(-540,-1100)`}>
          <Character kind="gilang" x={330} y={1640} scale={0.95} frame={f} expr={EXPR.laugh} talking={f / FPS < n / FPS - 1.4} armR={armR} />
          <Character kind="ilman" x={330 + 300} y={1640} scale={0.95} frame={f} expr={EXPR.smile} armR={ilArm} cup="R" flip />
        </g>
      </svg>
      <AbsoluteFill style={{background: "#000", opacity: lerp(f, n - 42, n - 4, 0, 1, Easing.linear)}} />
    </AbsoluteFill>
  );
};
