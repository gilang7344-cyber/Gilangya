// Waktu dihitung dari audio vo.mp3 (35.71 dtk). SPANS = bagian yang ada suaranya
// (hasil deteksi jeda). Kata disebar proporsional ke dalam SPANS.
// Kalau ada subtitle yang meleset, ubah angka SPANS atau OFFSETS di bawah.
export const FPS = 30;
export const DURATION_SEC = 35.71;
export const DURATION_FRAMES = Math.ceil(DURATION_SEC * FPS);

export const SPANS: [number, number][] = [
  [0, 4.94], [5.6, 12.55], [13.05, 14.96], [15.95, 20.05],
  [20.77, 22.32], [22.92, 25.84], [26.48, 35.25],
];

const RAW =
  "Kalian pasti pernah ngerasa kangen banget... sama tempat di mana kalian tumbuh dulu, kan? " +
  "Bayangin deh... kalau seandainya semua kenangan masa kecil kita di kampung halaman... " +
  "bisa tiba-tiba terulang lagi... bener-bener persis kayak dulu. " +
  "Suasana sore di Labanan... kampung halaman kami yang tenang... " +
  "Ah, kenalin... Hai, aku Gilang. Kalau ini siapa? Aku Ilman. " +
  "Iya, kami berdua sebenarnya sepupuan... dan hari ini kita bakal balik lagi ke tempat di mana semuanya bermula.";

export type Word = {text: string; start: number; end: number};

const total = SPANS.reduce((a, [s, e]) => a + (e - s), 0);
const toReal = (sp: number) => {
  let rest = sp;
  for (const [s, e] of SPANS) {
    const d = e - s;
    if (rest <= d) return s + rest;
    rest -= d;
  }
  return SPANS[SPANS.length - 1][1];
};

const tokens = RAW.split(/\s+/);
const weight = (t: string) => t.replace(/[^\p{L}]/gu, "").length + (/[.?!,]$/.test(t) ? 1.5 : 0);
const totalW = tokens.reduce((a, t) => a + weight(t), 0);
let acc = 0;
export const WORDS: Word[] = tokens.map((t) => {
  const s = toReal((acc / totalW) * total);
  acc += weight(t);
  const e = toReal((acc / totalW) * total);
  return {text: t.replace(/\.{2,}/g, "…"), start: s, end: e};
});

export const tOf = (needle: string) => {
  const w = WORDS.find((x) => x.text.toLowerCase().includes(needle.toLowerCase()));
  return w ? w.start : 0;
};

// Batas scene mengikuti kata pertama tiap scene di audio.
export const SCENE_T = [0, tOf("bayangin"), tOf("suasana"), tOf("ah,"), tOf("iya,"), DURATION_SEC];

// Potongan subtitle 3-5 kata.
export type Chunk = {words: Word[]; start: number; end: number};
export const CHUNKS: Chunk[] = (() => {
  const out: Chunk[] = [];
  let cur: Word[] = [];
  WORDS.forEach((w, i) => {
    cur.push(w);
    const punct = /[….?!,]$/.test(w.text);
    const next = WORDS[i + 1];
    const nextShort = next && weight(next.text) <= 3;
    if (cur.length >= 5 || (cur.length >= 3 && punct) || (cur.length === 4 && !nextShort)) {
      out.push({words: cur, start: cur[0].start, end: w.end});
      cur = [];
    }
  });
  if (cur.length) {
    if (cur.length < 2 && out.length) {
      const last = out[out.length - 1];
      last.words.push(...cur);
      last.end = cur[cur.length - 1].end;
    } else out.push({words: cur, start: cur[0].start, end: cur[cur.length - 1].end});
  }
  return out;
})();
