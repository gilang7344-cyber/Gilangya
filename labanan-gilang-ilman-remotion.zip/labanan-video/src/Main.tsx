import React from "react";
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from "remotion";
import {loadFont} from "@remotion/google-fonts/Poppins";
import {Fade, Scene1, Scene2, Scene3, Scene4, Scene5} from "./Scenes";
import {CHUNKS, FPS, SCENE_T, DURATION_FRAMES} from "./timing";

const {fontFamily} = loadFont("normal", {weights: ["800"], subsets: ["latin"]});

const Subtitles: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  const ch = CHUNKS.find((c) => t >= c.start - 0.05 && t < c.end + 0.3);
  if (!ch) return null;
  return (
    <div style={{position: "absolute", left: 60, right: 60, bottom: 380, display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "6px 22px",
      fontFamily, fontWeight: 800, fontSize: 96, lineHeight: 1.15, textAlign: "center", textTransform: "uppercase"}}>
      {ch.words.map((w, i) => {
        const on = t >= w.start && t < (ch.words[i + 1]?.start ?? ch.end + 0.3);
        return (
          <span key={i} style={{color: on ? "#ffe066" : "#fff", transform: `scale(${on ? 1.12 : 1})`, display: "inline-block",
            WebkitTextStroke: "10px #3b2250", paintOrder: "stroke fill", textShadow: "0 8px 0 rgba(59,34,80,.55)"}}>{w.text}</span>
        );
      })}
    </div>
  );
};

export const Main: React.FC = () => {
  const S = [Scene1, Scene2, Scene3, Scene4, Scene5];
  return (
    <AbsoluteFill style={{background: "#000"}}>
      <Audio src={staticFile("vo.mp3")} />
      {S.map((Sc, i) => {
        const from = Math.round(SCENE_T[i] * FPS);
        const end = i === 4 ? DURATION_FRAMES : Math.round(SCENE_T[i + 1] * FPS) + 8; // tumpang tindih untuk crossfade
        return (
          <Sequence key={i} from={from} durationInFrames={end - from}>
            {i === 0 ? <Sc /> : <Fade><Sc /></Fade>}
          </Sequence>
        );
      })}
      <Subtitles />
    </AbsoluteFill>
  );
};
