import React from "react";
import {Composition} from "remotion";
import {Main} from "./Main";
import {FPS, DURATION_FRAMES} from "./timing";

export const Root: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={DURATION_FRAMES} fps={FPS} width={1080} height={1920} />
);
